# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class TencentcareerItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    # 职位名称
    RecruitPostName = scrapy.Field()
    # 职位工作地点
    PostLocation = scrapy.Field()
    # 职位类别
    CategoryName = scrapy.Field()
    # 职位介绍
    Responsibility = scrapy.Field()
    # 职位需求
    Requirement = scrapy.Field()
    # post id
    PostId = scrapy.Field()
    # post url
    PostURL = scrapy.Field()
    # 上次更新时间
    LastUpdateTime = scrapy.Field()
