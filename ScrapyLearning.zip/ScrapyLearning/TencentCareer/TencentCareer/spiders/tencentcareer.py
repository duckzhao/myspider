import scrapy
from TencentCareer.items import TencentcareerItem
import json
import time

class TencentcareerSpider(scrapy.Spider):
    name = 'tencentcareer'
    allowed_domains = ['careers.tencent.com']
    base_url = 'https://careers.tencent.com/tencentcareer/api/post/Query?timestamp=1599038644912&countryId=&cityId=&bgIds=&productId=&categoryId=40001001,40001002,40001003,40001004,40001005,40001006&parentCategoryId=&attrId=&keyword=&pageIndex={}&pageSize=10&language=zh-cn&area=cn'
    page_num = 1
    detail_data_url = 'https://careers.tencent.com/tencentcareer/api/post/ByPostId?timestamp=1599040020694&postId={}&language=zh-cn'
    start_urls = [base_url.format(page_num)]

    # 解析职位列表页返回的数据
    def parse(self, response):
        if json.loads(response.body)['Data']['Posts']:
            json_data = json.loads(response.body)['Data']['Posts']
            for post_data in json_data:
                item = TencentcareerItem()
                item['PostId'] = post_data['PostId']
                item['RecruitPostName'] = post_data['RecruitPostName']
                item['PostLocation'] = post_data['CountryName'] + '-' +post_data['LocationName']
                item['CategoryName'] = post_data['CategoryName']
                item['PostURL'] = post_data['PostURL']
                yield scrapy.Request(url=self.detail_data_url.format(post_data['PostId']), callback=self.parse_detail_info, meta={'item': item})
                self.page_num += 1
                yield scrapy.Request(url=self.base_url.format(self.page_num), callback=self.parse)


    def parse_detail_info(self, response):
        json_data = json.loads(response.body)['Data']
        item = response.meta['item']
        item['Requirement'] = json_data['Requirement']
        item['LastUpdateTime'] = json_data['LastUpdateTime']
        item['Responsibility'] = json_data['Responsibility']
        yield item


