# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import json
import time

class TencentcareerPipeline:
    def __init__(self):
        self.f = open('./TencentCareerInfo.json', mode='w')
        self.f.write('[\n')

    def process_item(self, item, spider):
        item_data = json.dumps(dict(item), ensure_ascii=False)
        self.f.write(item_data + ',\n')
        return item

    def cloce_spider(self, spider):
        self.f.close()
        self.f.write(']')