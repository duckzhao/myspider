import scrapy
from Tuke88.items import Tuke88Item

class TukespiderSpider(scrapy.Spider):
    name = 'tukespider'
    allowed_domains = ['tuke88.com']
    start_urls = ['http://tuke88.com/']

    def parse(self, response):
        father_node = response.xpath('//ul/li[@class="nav"][5] | //ul/li[@class="nav"][6]')
        for node in father_node:
            url = node.xpath("./a/@href").extract()[0]
            url = 'http://www.tuke88.com' + url
            yield scrapy.Request(url=url, callback=self.parse_dowurl)

    def parse_dowurl(self, response):
        father_dow_node = response.xpath('//div[@class="audio-list"]/div/audio/source/@src').extract()
        father_name_node = response.xpath('//div[@class="audio-list"]/div/div[@class="info"]/a[@class="title"]/text()').extract()
        father_link_node = response.xpath('////div[@class="audio-list"]/div/div[@class="info"]/a[@class="title"]/@href').extract()
        # 没有页码时，长度为0
        next_page = response.xpath('//div[@class="page"]/a[text()="下一页"]/@href').extract()
        for music_name, music_url, music_link in zip(father_name_node, father_dow_node, father_link_node):
            item = Tuke88Item()
            item['music_name'] = music_name
            item['music_url'] = music_url
            item['music_link'] = 'http://www.tuke88.com' + music_link
            yield item
        if len(next_page):
            yield scrapy.Request(url=next_page[0], callback=self.parse_dowurl)

