# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
from scrapy.pipelines.files import FilesPipeline
import scrapy
import json

class Tuke88Pipeline(FilesPipeline):

    # 重写父类ImagesPipeline，方法
    def get_media_requests(self, item, info):
        music_url = item['music_url']
        # 便于后续处理下载名称，故将item传过去
        yield scrapy.Request(music_url, meta=item)

    def file_path(self, request, response=None, info=None):
        meta = request.meta
        file_path = f'{meta["music_name"]}.mp3'
        return file_path


class Tuke88OtherInfoWrite(object):
    def process_item(self, item, spider):
        FILES_STORE = r'C:\Users\ZhaoKun\Desktop\pythonProject\ScrapyLearning\Tuke88\Tuke88\info.json'
        with open(FILES_STORE, mode='a+') as f:
            f.write(json.dumps(dict(item), ensure_ascii=False) + ',\n')
        print(f'{item["music_name"]}下载成功！')
        return item