import scrapy


class TestspiderSpider(scrapy.Spider):
    name = 'testspider'
    allowed_domains = ['http://baidu.com']
    start_urls = ['http://baidu.com/']

    def parse(self, response):
        print(response.body)
