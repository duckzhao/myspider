# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class ZuowenwangItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    zuowen_title = scrapy.Field()
    zuowen_content = scrapy.Field()
    zuowen_href = scrapy.Field()
    zuowen_banquan = scrapy.Field()
    zuowen_zishu = scrapy.Field()
