import scrapy
from zuowenwang.items import ZuowenwangItem
import re
import time

class ZuowenSpider(scrapy.Spider):
    name = 'zuowen'
    allowed_domains = ['zuowen.com']
    offset = 1
    url = 'http://www.zuowen.com/zhongkaozw/youxiu/index_{}.shtml'
    start_urls = [url.format(offset)]

    def parse(self, response):
        zuowen_href_list = response.xpath('//div[@class="artbox_l"]/div[1]/a/@href').extract()
        for temp_url in zuowen_href_list:
            item = ZuowenwangItem()
            item['zuowen_href'] = temp_url
            yield scrapy.Request(url=temp_url, callback=self.parse_detial, meta={'item': item})

        if self.offset < 150:
            self.offset += 1
            yield scrapy.Request(url=self.url.format(self.offset), callback=self.parse)

    def parse_detial(self, response):
        item = response.meta['item']
        zuowen_title = re.findall(r'<title>(.*?)</title>', response.text, re.DOTALL)[0].split()[0]
        item['zuowen_title'] = zuowen_title
        zuowen_content = response.xpath('//div[@class="con_content"]/p/text()').extract()
        item['zuowen_content'] = ''.join(zuowen_content)
        item['zuowen_zishu'] = len(item['zuowen_content'].replace(' ',''))
        item['zuowen_banquan'] = response.xpath('//div[@class="composition"]//p').extract_first()
        yield item

