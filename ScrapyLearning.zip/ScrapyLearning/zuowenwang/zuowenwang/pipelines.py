# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import json

class ZuowenwangPipeline:
    def process_item(self, item, spider):
        with open('./new_chuzhong_data.json', mode='a+', encoding='utf-8') as f:
            f.write(json.dumps(dict(item), ensure_ascii=False) + ',\n')
            print(f"{item['zuowen_href']} 爬取完毕！")
        return item
