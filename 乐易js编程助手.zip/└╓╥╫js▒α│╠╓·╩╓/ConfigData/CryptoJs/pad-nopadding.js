CryptoJS.pad.NoPadding = {
    pad: function () {}, unpad: function () {}
};
